%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Introduction au calcul scientifique par la pratique %%%%%%%
%%%%%%%    I. Danaila, P. Joly, S. M. Kaber et M. Postel    %%%%%%%
%%%%%%%                 Dunod, 2005                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  R�solution des �quations de Navier-Stokes 2D   %
%  domaine rectangulaire (Lx,Ly)                  % 
%  avec des conditions de p�riodicit� en x et y   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

     close all; clear all;
     format long e;
%===============================%
%  Variables globales           %
%===============================%
     global dx dy Lx Ly;
     global nxm nym ;
     global ip im jp jm ic jc;

%===============================%
%  Donn�es du programme         %
%  Condition initiale           %
%===============================%
icas=input(['Cas de calcul\n'... 
                            '1=Kelvin-Helmholtz (1)\n'...
                            '2=Kelvin-Helmholtz (2)\n'...
                            '3=dipole (1)\n'...
                            '4=dipole (2)\n']);
switch icas
case {1,2}
  fprintf('Instabilit� de Kelvin-Helholtz \n');  
      Lx=2; Ly=1;
      nx=65;ny=65;
      rey=1000;
      pec=1000;

      nitermax=210;
      nprint=10;niso=10;  
   case{3,4}
    fprintf('Evolution d''un dipole de vorticite \n');  
      Lx=1; Ly=1;
      nx=65;ny=65;
      rey=1000;
      pec=1000;

      nitermax=300;
      nprint=10;niso=10;
   end  

%===============================%
%  Maillage                     %
%===============================%
      nxm=nx-1  ;           nym=ny-1;
      dx=Lx/nxm ;           dy=Ly/nym;

      ic=1:nxm;             jc=1:nym; 

      xc=(ic-1)*dx ;        yc=(jc-1)*dy ;
      xm=(ic-0.5)*dx;       ym=(jc-0.5)*dy;

      ip=ic+1; ip(nxm)=1;   jp=jc+1; jp(nym)=1;
      im=ic-1; im(1)=nxm;   jm=jc-1; jm(1)=nym;
                             
[xx,yy]=meshgrid(xm,ym);xx=xx';yy=yy';

%===============================%
%  Initialisation               %
%===============================%

      u   =zeros(nxm,nym);
      v   =zeros(nxm,nym);

      gpu  =zeros(nxm,nym);
      gpv  =zeros(nxm,nym);
      hcu  =zeros(nxm,nym);
      hcv  =zeros(nxm,nym);
      hcs  =zeros(nxm,nym);

      pres =zeros(nxm,nym);
      sca  =zeros(nxm,nym);
     
      rhs  =zeros(nxm,nym);
      phi  =zeros(nxm,nym);

%===============================%
%  Condition initiale           %
%===============================%
switch icas
case 1
                       % champ initial
      u  =init_KH(Lx,Ly,xc,ym,1,Ly/4,20,0.25,0.5*Lx);
      sca=init_KH(Lx,Ly,xm,ym,1,Ly/4,20,0.00,0.5*Lx);
                       % pas de temps 
      cfl=0.2;
case 2
                       % champ initial
      u  =init_KH(Lx,Ly,xc,ym,1,Ly/4,20,0.25,0.25*Lx);
      sca=init_KH(Lx,Ly,xm,ym,1,Ly/4,20,0.00,0.25*Lx);
                       % pas de temps 
      cfl=0.1;
case 3
                       % premier tourbillon      
[rhs,phi]=init_vortex(Lx,Ly,xc,yc,Lx/4,Ly/2+0.05,0.,0,1);
u=u+rhs;v=v+phi;
                       % deuxi�me tourbillon
[rhs,phi]=init_vortex(Lx,Ly,xc,yc,Lx/4,Ly/2-0.05,-0.,0,-1);
u=u+rhs;v=v+phi;
                       % champ scalaire (au milieu du domaine)
      sca(nxm/2-10:nxm/2+10,:)=ones(21,nym);
                       % pas de temps
      cfl=0.4;
case 4
                        % premi�re paire de tourbillons -> dip�le 1
[rhs,phi]=init_vortex(Lx,Ly,xc,yc,Lx/4,Ly/2+0.05,0.,0,1);
u=u+rhs;v=v+phi;
[rhs,phi]=init_vortex(Lx,Ly,xc,yc,Lx/4,Ly/2-0.05,-0.,0,-1);
u=u+rhs;v=v+phi;
                        % deuxi�me paire de tourbillons -> dip�le 2
[rhs,phi]=init_vortex(Lx,Ly,xc,yc,3*Lx/4,Ly/2+0.05,-0.,0,-1);
u=u+rhs;v=v+phi;
[rhs,phi]=init_vortex(Lx,Ly,xc,yc,3*Lx/4,Ly/2-0.05,-0.,0,1);
u=u+rhs;v=v+phi;
                       % champ scalaire (au milieu du domaine)
      sca(nxm/2-10:nxm/2+10,:)=ones(21,nym);
                       % pas de temps
      cfl=0.4;        
end  

% visualisation de la condition initiale
ivisu=1;
figure(1);set(1,'MenuBar','none');
     visu_vort(xc,yc,u,v,11,ivisu,0);
figpos=get(1,'Position');
figure(2);set(2,'MenuBar','none');
set(2,'Position',[figpos(1) figpos(2)-figpos(4)-20 figpos(3) figpos(4)]);
visu_sca (xm,ym,sca,11,ivisu,0);


%===============================%
%   Optimisation ADI            %
%===============================%
      dt=calc_dt(u,v,cfl);       % pas de temps
      fprintf('Pas de temps dt=%d \n',dt);  
      
      bx=0.5*dt/(dx*dx)/rey;
      by=0.5*dt/(dy*dy)/rey;

[amix,apix,alphx,xs2x]=ADI_init(-bx*ones(1,nxm),(1+2*bx)*ones(1,nxm),-bx*ones(1,nxm));
[amiy,apiy,alphy,xs2y]=ADI_init(-by*ones(1,nym),(1+2*by)*ones(1,nym),-by*ones(1,nym));

%===============================%
%   Optimisation �q pression    %
%===============================%

      kl=(cos(2*pi/nxm*(ic-1))-1)*2/(dx*dx);

      am=ones(nxm,nym)/(dy*dy);
      ac=(-2/(dy*dy)+kl)'*ones(1,nym);
      ap=ones(nxm,nym)/(dy*dy);

          % nombre d'onde = 0
      am(1,1)=0;
      ac(1,1)=1;
      ap(1,1)=0;
     
      [am,ap,ac,xs2]=Phi_init(am,ac,ap);
      
%===============================%
%   Avancement en temps         %
%===============================%

niter=0; temps=0;
affiche_div(u,v,niter,temps);

tc=cputime;
   while(niter <= nitermax)
      
         niter=niter+1;temps=temps+dt;

      % �quation de qmvt pour u
      %===========================
                                     % membre de droite
	 rhs =-0.5*hcu;
	 hcu = calc_hcu(u,v);
	 rhs = dt*(rhs+1.5*hcu-gpu+calc_lap(u)/rey);
                                     % premier pas ADI
	 du1 = ADI_step(amix,apix,alphx,xs2x,rhs');
                                     % deuxi�me pas ADI
	 du  = ADI_step(amiy,apiy,alphy,xs2y,du1');
                                     % u non-solenoidal
          u = u+du;

      % �quation de qmvt pour v
      %===========================
                                     % membre de droite
	 rhs =-0.5*dt*hcv;
	 hcv = calc_hcv(u,v);
	 rhs = dt*(rhs+1.5*hcv-gpv+calc_lap(v)/rey);
                                     % premier pas ADI
	 du1 = ADI_step(amix,apix,alphx,xs2x,rhs');
                                     % deuxieme pas ADI
	  du = ADI_step(amiy,apiy,alphy,xs2y,du1');
                                     % u non-sol�no�dal
          v=v+du;

      % calcul de la divergence du champ non-sol�no�dal
      %===========================
  
          rhs=((u(ip,jc)-u)/dx+ (v(ic,jp)-v)/dy)/dt;

      % r�solution de l'�quation de Poisson
      %===========================

          uf=fft(rhs); uf(1,1)=0;
          uff=Phi_step(am,ap,ac,xs2,uf);
          phi=real(ifft(uff));

      % correction du champ de vitesse     
      %===========================    

          u=u-dt*(phi-phi(im,jc))/dx;
          v=v-dt*(phi-phi(ic,jm))/dy;

      % calcul de la pression    
      %===========================    

          pres=pres+phi-dt/(2*rey)*calc_lap(phi);

      % nouveau gradient de pression    
      %===========================    

          gpu=(pres-pres(im,jc))/dx;
          gpv=(pres-pres(ic,jm))/dy;

      % �quation pour le scalaire passif
      %=================================
                                     % membre de droite
	 rhs =-0.5*hcs;
	 hcs = calc_hcs(u,v,sca);
	 rhs = dt*(rhs+1.5*hcs+calc_lap(sca)/pec);
                                     % premier pas ADI
	 du1 = ADI_step(amix,apix,alphx,xs2x,rhs');
                                     % deuxi�me pas ADI
	  du = ADI_step(amiy,apiy,alphy,xs2y,du1');
                                     % champ scalaire
          sca=sca+du;

      % visualisation de l'�coulement
      %==============================

         if(mod(niter,nprint) == 0); 
             affiche_div(u,v,niter,temps);ivisu=ivisu+1;
             figure(1);visu_vort(xc,yc,u,v,niso,ivisu,temps);
             %fname=['print -depsc figV' num2str(ivisu)];eval(fname);
             figure(2);visu_sca (xm,ym,sca,niso,ivisu,temps);
             %fname=['print -depsc figS' num2str(ivisu)];eval(fname);
          end;

    end;
fprintf('temps cpu =%d\n',cputime-tc);
