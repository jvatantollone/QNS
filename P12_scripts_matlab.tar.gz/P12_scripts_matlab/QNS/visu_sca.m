%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Introduction au calcul scientifique par la pratique %%%%%%%
%%%%%%%    I. Danaila, P. Joly, S. M. Kaber et M. Postel    %%%%%%%
%%%%%%%                 Dunod, 2005                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Visualisation des contours du scalaire pas.   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function visu_sca(x,y,sca,ncont,ivisu,temps)

global dx dy
global im ip jp jm ic jc


[xx,yy]=meshgrid(x,y);xx=xx';yy=yy';
pcolor(xx,yy,sca);axis equal;shading('interp');drawnow
set(gca,'FontSize',16);xlabel('x');ylabel('y');
title(['Scalaire   t=' num2str(temps)],'FontSize',16);