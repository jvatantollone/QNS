%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Introduction au calcul scientifique par la pratique %%%%%%%
%%%%%%%    I. Danaila, P. Joly, S. M. Kaber et M. Postel    %%%%%%%
%%%%%%%                 Dunod, 2005                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Calcul des termes explicites pour v           %
%      Hc_v=-(d(uv)/dx + d(v^2)/dy)               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function hcv=calc_hcv(u,v)

global dx dy
global im ip jp jm ic jc

hcv = -0.25/dx*((u(ip,jc)+u(ip,jm)).*(v+v(ip,jc)) - (u(ic,jm)+u).*(v(im,jc)+v))...
      -0.25/dy*((v(ic,jp)+v).*(v(ic,jp)+v)-(v(ic,jm)+v).*(v(ic,jm)+v));
