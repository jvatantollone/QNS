%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Introduction au calcul scientifique par la pratique %%%%%%%
%%%%%%%    I. Danaila, P. Joly, S. M. Kaber et M. Postel    %%%%%%%
%%%%%%%                 Dunod, 2005                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Condition initiale -> jet 2D                  %
%     pour l'instabilit� de Kelvin-helmholtz      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function u=init_KH(Lx,Ly,x,y,U0,Rj,Pj,Ax,lamx)

global dx dy
global im ip jp jm ic jc
           % maillage 2D
[xx,yy]=meshgrid(x,y);xx=xx';yy=yy';
           % coordonn�e $y$ locale
rr=yy-Ly/2;
           % vitesse $u$
u=U0*0.5d0*(1.d0+tanh(0.5*Pj*(1-abs(rr)/Rj)));
           % perturbation en $x$
u=u+Ax*u.*sin(2*pi/lamx*xx);
