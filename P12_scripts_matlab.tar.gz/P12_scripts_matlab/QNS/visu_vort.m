%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Introduction au calcul scientifique par la pratique %%%%%%%
%%%%%%%    I. Danaila, P. Joly, S. M. Kaber et M. Postel    %%%%%%%
%%%%%%%                 Dunod, 2005                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Visualisation des contours de vorticite       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function visu_vort(x,y,u,v,ncont,ivisu,temps)

global dx dy
global im ip jp jm ic jc
            % calcul de la vorticit�
omeg=(v(ic,jc)-v(im,jc))/dx-(u(ic,jc)-u(ic,jm))/dy ;
            % maillage 2D
[xx,yy]=meshgrid(x,y);xx=xx';yy=yy';
            % contours
            pcolor(xx,yy,omeg);axis equal;shading('interp');drawnow
            
set(gca,'FontSize',16);xlabel('x');ylabel('y');
title(['Vorticite  t=' num2str(temps)],'FontSize',16);