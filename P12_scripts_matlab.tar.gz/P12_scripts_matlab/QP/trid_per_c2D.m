%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Introduction au calcul scientifique par la pratique %%%%%%%
%%%%%%%    I. Danaila, P. Joly, S. M. Kaber et M. Postel    %%%%%%%
%%%%%%%                 Dunod, 2005                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     R�solution du systeme (coeff 2D)                           %
% aa(j,i)*X(j,i-1)+ab(j,i)*X(j,i)+ac(j,i)*X(j,i+1)=fi(j,i),      %
%               i=1:n                                            %
%  pour chaque  j=1:m                                            %
%  la periodicit� est donn�e par X(j,1)=X(j,n)                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
       function fi=trid_per_c2D(aa,ab,ac,fi)

       [m,n]=size(aa);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modification de la matrice du syst�me (1er et dernier el diag) %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
         ab(:,1)=ab(:,1)-aa(:,1);
         ab(:,n)=ab(:,n)-ac(:,n);
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initialisation du second membre pour X2                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
	       xs2=zeros(m,n);
         xs2(:,1)=aa(:,1);    
         xs2(:,n)=ac(:,n);    

%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% R�solution du syst�me tridiagonal                                %
% aa(j,i)*X(j,i-1)+ab(j,i)*X(j,i)+ac(j,i)*X(j,i+1)=xs2(j,i),       %
%      i=1,n                                                       %
% -> stockage dans xs2                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%--> algorithme de Thomas 
%-->                  alph(i)=1/beta(i)
%                     aa(i)=aa(i)/beta(i-1)
%                     ac(i)=ac(i)/beta(i)

          alph=zeros(m,n);
          alph(:,1)=1.d0./ab(:,1);
        for i=2:n
          alph(:,i)=1.d0./(ab(:,i)-aa(:,i).*ac(:,i-1).*alph(:,i-1));
          aa(:,i)=aa(:,i).*alph(:,i-1);
          ac(:,i-1)=ac(:,i-1).*alph(:,i-1);
	end

%
%-->r�solution du syst�me [M*] X2 = v1_x
%                       ab(i)=beta(i)*gamma(i)

          ab(:,1)=xs2(:,1);
        for i=2:n
	        ab(:,i)=xs2(:,i)-aa(:,i).*ab(:,i-1);
        end

%                       xs2(i) = X2(i) 
        	xs2(:,n)=ab(:,n).*alph(:,n);
      for i=n-1:-1:1
        xs2(:,i)=ab(:,i).*alph(:,i)-ac(:,i).*xs2(:,i+1);
      end
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% R�solution du syst�me tridiagonal                                %
% aa(j,i)*X(j,i-1)+ab(j,i)*X(j,i)+ac(j,i)*X(i+1)=fi(j,i), i=1,n    %
%   -> stockage dans fi                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%***------------------------------------------------------------
%***   Substitution directe
%***------------------------------------------------------------

      for i=2:n
	     fi(:,i)= fi(:,i)-aa(:,i).*fi(:,i-1);
      end


%***------------------------------------------------------------
%***  Substitution inverse -->	dudx1(i)=X1(i)
%                            =gamma(n), i=n
%                            =gamma(i)-[c(i)/beta(i)]*X1(i+1)
%***------------------------------------------------------------

        fi(:,n)=fi(:,n).*alph(:,n);
%

        for i=n-1:-1:1
            fi(:,i)=fi(:,i).*alph(:,i)-ac(:,i).*fi(:,i+1);
        end
%***------------------------------------------------------------
%***   Solution finale   	-->  v2_x = X*
%                              dudx1 = X = [X1] - [X*] [X2]
%***------------------------------------------------------------
	       xs1=zeros(m,1);
          xs1=(fi(:,1)+fi(:,n))./(1.d0+xs2(:,1)+xs2(:,n));

%
        for  i=1:n
          fi(:,i)=fi(:,i)-xs1.*xs2(:,i);
        end
