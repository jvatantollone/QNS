%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Introduction au calcul scientifique par la pratique %%%%%%%
%%%%%%%    I. Danaila, P. Joly, S. M. Kaber et M. Postel    %%%%%%%
%%%%%%%                 Dunod, 2005                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  r�solution de l'�quation                       %
%              du/dt -Delta u=f                   % 
%  domaine rectangulaire (L_x,L_y)                % 
%  avec des conditions de p�riodicit� en x et y   %
%=================================================%
%  u(i,j) calcul� au point (xc(i),ym(j))          %
%=================================================%
% Sch�ma d'Adams-Basfort + Crank-Nicholson        %
% (u^{n+1}-u^n)/dt=(3/2)H_c^n -(1/2)*H_c^{n-1}    %
%                    + (1/2)Delta(u^n+u^{n+1})    %
% condition CFL � imposer                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

     close all; clear all;
     format long e;

%===============================%
%  Variables globales           %
%===============================%
     global dx dy Lx Ly;
     global nxm nym ;
     global ip im jp jm ic jc;

%===============================%
%  Donn�es du programme         %
%===============================%
      Lx=1; Ly=2;
      nx=21;ny=51;
%===============================%
%  Maillage                     %
%===============================%
      nxm=nx-1  ;           nym=ny-1;
      dx=Lx/nxm ;           dy=Ly/nym;

      ic=1:nxm;             jc=1:nym; 

      xc=(ic-1)*dx ;        yc=(jc-1)*dy ;
      xm=(ic-0.5)*dx;       ym=(jc-0.5)*dy;

      ip=ic+1; ip(nxm)=1;   jp=jc+1; jp(nym)=1;
      im=ic-1; im(1)=nxm;   jm=jc-1; jm(1)=nym;

                        % points de calcul (maillage 2D)
      [xx,yy]=meshgrid(xc,ym);
       xx=xx';yy=yy';

%===============================%
%  Initialisation               %
%===============================%

      u   =zeros(nxm,nym);
      du  =zeros(nxm,nym);
      hc  =zeros(nxm,nym);
      rhs =zeros(nxm,nym);

%===============================%
%   Pas de temps                %
%===============================%

      dt=0.5/(1/(dx*dx)+1/(dy*dy))*100;
      bx=0.5*dt/(dx*dx);
      by=0.5*dt/(dy*dy);

%===============================%
% Optimisation syst p�riodique  %
%===============================%

[amix,apix,alphx,xs2x]=ADI_init(-bx*ones(1,nxm),(1+2*bx)*ones(1,nxm),-bx*ones(1,nxm));
[amiy,apiy,alphy,xs2y]=ADI_init(-by*ones(1,nym),(1+2*by)*ones(1,nym),-by*ones(1,nym));


%===============================%
%   Avancement en temps         %
%===============================%

       eps=1; nitermax=1000;
       niter=0;temps=0;

tcpu=cputime;
while((eps > 1e-6)&(niter <= nitermax))
   niter=niter+1;temps=temps+dt;
				                           % membre de droite
	 rhs = -0.5*dt*hc;
	 hc  = calc_hc(Lx,Ly,xx,yy,u);
	 rhs = rhs+1.5*dt*hc+dt*calc_lap(u);
                                     % premier pas ADI
	 du1 = ADI_step(amix,apix,alphx,xs2x,rhs');
                                     % deuxi�me pas ADI
	 du  = ADI_step(amiy,apiy,alphy,xs2y,du1');
                                     % crit�re d'arr�t
   eps = norme_L2(du);
                                     % calcul de u^{n+1}
   u   = u+du;
                                     % suivi de la convergence

   if(mod(niter,10) == 0); 
     fprintf('It=%d   temps=%d ||u-uold||=%d \n',niter,temps,eps);
   end;
   convt(niter)=niter;
   conve(niter)=eps;
end;

%===============================%
%   Solution exacte             %
%===============================%

fex=fexact(Lx,Ly,xx,yy);   

fprintf('\n=====Fin calcul ======= temps cpu =%d\n',cputime-tcpu)
     fprintf('It=%d   temps=%d ||u-uold||=%d \n',niter,temps,eps);
     fprintf('Norme ||Uex-Unum|| =%d \n',norme_L2(fex-u));

%===============================%
%   Repr�sentation graphique    %
%   sol num�rique/ sol exacte   %
%===============================% 

figure;
visu_isos(xx,yy,u,fex,11);
          
figure;
semilogy(convt,conve,'ro-','LineWidth',2);
set(gca,'FontSize',24);xlabel('niter');ylabel('\epsilon');
title('Convergence de la m�thode implicite','FontSize',24);
