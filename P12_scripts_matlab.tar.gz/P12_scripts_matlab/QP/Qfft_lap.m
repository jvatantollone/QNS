%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Introduction au calcul scientifique par la pratique %%%%%%%
%%%%%%%    I. Danaila, P. Joly, S. M. Kaber et M. Postel    %%%%%%%
%%%%%%%                 Dunod, 2005                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  r�solution de l'�quation                       %
%              -Delta u=f                         % 
%  domaine rectangulaire (L_x,L_y)                % 
%  avec des conditions de p�riodicit� en x et y   %
%=================================================%
%  u(i,j) calcul� au point (xc(i),ym(j))          %
%=================================================%
%   Transform�e de Fourier (FFT) en x             %
%     + r�solution de syst�me tridiag per en y    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

     close all; clear all;
     format long e;

%===============================%
%  Variables globales           %
%===============================%
     global dx dy Lx Ly;
     global nxm nym ;
     global ip im jp jm ic jc;

%===============================%
%  Donn�es du programme         %
%===============================%
      Lx=1; Ly=2;
      nx=65;ny=129;
%===============================%
%  Maillage                     %
%===============================%
      nxm=nx-1  ;           nym=ny-1;
      dx=Lx/nxm ;           dy=Ly/nym;

      ic=1:nxm;             jc=1:nym; 

      xc=(ic-1)*dx ;        yc=(jc-1)*dy ;
      xm=(ic-0.5)*dx;       ym=(jc-0.5)*dy;

      ip=ic+1; ip(nxm)=1;   jp=jc+1; jp(nym)=1;
      im=ic-1; im(1)=nxm;   jm=jc-1; jm(1)=nym;

                        % points de calcul (maillage 2D)
      [xx,yy]=meshgrid(xc,ym);
       xx=xx';yy=yy';

%===============================%
%  Initialisation               %
%===============================%
      u   =zeros(nxm,nym);

%===============================%
%  Nombre d'onde + FFT          %
%===============================%
tcpu=cputime;
                   % vecteur nombre d'onde
      kl=(cos(2*pi/nxm*(ic-1))-1)*2/(dx*dx);   
                   % membre de droite
      rhs=-fsource(Lx,Ly,xx,yy);
                   % FFT de chaque colonne
      uf=fft(rhs); 

%===============================%
%  R�solution du syst en y      %
%===============================%
                   % coefficients de la matrice
      am = ones(nxm,nym)/(dy*dy);
      ac = (-2/(dy*dy)+kl)'*ones(1,nym);
      ap = ones(nxm,nym)/(dy*dy);
                   % nombre d'onde k=0
      uf(1,1)=0;
      am(1,1)=0;
      ac(1,1)=1;
      ap(1,1)=0;     
                   % optimisation du calcul
      [am,ap,ac,xs2] = Phi_init(am,ac,ap);
                 uff = Phi_step(am,ap,ac,xs2,uf);
                   %sans optimisation
%                uff = trid_per_c2D(am,ac,ap,uf);

%===============================%
%  FFT inverse                  %
%===============================
       u=ifft(uff);u=real(u);

%===============================%
%   Solution exacte             %
%===============================
         fex=fexact(Lx,Ly,xx,yy);   

%===============================%
%   Constante pour la sol num   %
%===============================
        c0 = fex(1,1)-u(1,1);
         u = u+c0;

%===============================%
%   Comparaison solutions       %
%===============================%

fprintf('\n=====Fin calcul ======= temps cpu =%d\n',cputime-tcpu)
     fprintf('Norme ||Uex-Unum|| =%d \n',norme_L2(fex-u));
     
%===============================%
%   Repr�sentation graphique    %
%   sol num�rique/ sol exacte   %
%===============================% 

figure;
visu_isos(xx,yy,u,fex,11);