%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Introduction au calcul scientifique par la pratique %%%%%%%
%%%%%%%    I. Danaila, P. Joly, S. M. Kaber et M. Postel    %%%%%%%
%%%%%%%                 Dunod, 2005                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Calcul des termes explicites (pb. non-lin�aire)  %
%     Hc^n=f^n - d(u^2)/dx                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function hc=calc_hc(Lx,Ly,x,y,u)

global dx dy
global im ip jp jm ic jc
             hc = fsource_nonl(Lx,Ly,x,y)...
- 0.25/dx*((u(ip,jc)+u).*(u(ip,jc)+u) - (u(im,jc)+u).*(u(im,jc)+u));
             