%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Introduction au calcul scientifique par la pratique %%%%%%%
%%%%%%%    I. Danaila, P. Joly, S. M. Kaber et M. Postel    %%%%%%%
%%%%%%%                 Dunod, 2005                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  r�solution de l'�quation                       %
%              du/dt -Delta u=f                   % 
%  domaine rectangulaire (L_x,L_y)                % 
%  avec des conditions de p�riodicit� en x et y   %
%=================================================%
%   Sch�ma explicite                              %
%     u^{n+1}=u^{n} + dt*(f^n + Delta(u^n))       %
%   condition de stabilit�                        %
%     dt < 0.5 /(1/dx^2+1/dy^2)                   %
%=================================================%
%   u(i,j) est calcul� au point (xc(i),ym(j))     %         
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

     close all; clear all; format long e
%===============================%
%  Variables globales           %
%===============================%
     global dx dy Lx Ly;
     global nxm nym ;
     global ip im jp jm ic jc;

%===============================%
%  Donn�es du programme         %
%===============================%
      Lx=1; Ly=2;
      nx=21;ny=51;
%===============================%
%  Maillage                     %
%===============================%
      nxm=nx-1  ;           nym=ny-1;
      dx=Lx/nxm ;           dy=Ly/nym;

      ic=1:nxm;             jc=1:nym; 

      xc=(ic-1)*dx ;        yc=(jc-1)*dy ;
      xm=(ic-0.5)*dx;       ym=(jc-0.5)*dy;

      ip=ic+1; ip(nxm)=1;   jp=jc+1; jp(nym)=1;
      im=ic-1; im(1)=nxm;   jm=jc-1; jm(1)=nym;

      [xx,yy]=meshgrid(xc,ym); % points de calcul (maillage 2D)
       xx=xx';yy=yy';

%===============================%
%  Initialisation               %
%===============================%
      u   =zeros(nxm,nym);
     du   =zeros(nxm,nym);

%===============================%
%   Pas de temps                %
%===============================
      dt=0.5/(1/(dx*dx)+1/(dy*dy));

%===============================%
%   Avancement en temps         %
%===============================%
       eps=1; nitermax=10000;
       niter=0;temps=0;

tcpu=cputime;  % estimation du temps de calcul : initialisation

while((eps > 1e-6)&(niter <= nitermax))

         niter=niter+1;temps=temps+dt;
                            % calcul du vecteur u^{n+1}-u^n
         du=dt*(fsource(Lx,Ly,xx,yy)+calc_lap(u));
                            % crit�re d'arr�t
         eps=norme_L2(du);
                            % solution u^{n+1}
         u=u+du;
                            % suivi de la convergence
         if(mod(niter,10) == 0); 
            fprintf('It=%d   temps=%d ||u-uold||=%d \n',niter,temps,eps)
         end;
         convt(niter)=niter;
         conve(niter)=eps;
end;
     
%===============================%
%   Solution exacte             %
%===============================%
         fex=fexact(Lx,Ly,xx,yy);   
         
     fprintf('\n=====Fin calcul ======= temps cpu =%d\n',cputime-tcpu)
     fprintf('It=%d   temps=%d ||u-uold||=%d \n',niter,temps,eps);
     fprintf('Norme ||Uex-Unum|| =%d \n',norme_L2(fex-u));

%===============================%
%   Repr�sentation graphique    %
%   sol num�rique/ sol exacte   %
%===============================%     
     figure;
     visu_isos(xx,yy,u,fex,11);
          
     figure;
     semilogy(convt,conve,'r-','LineWidth',2);
     set(gca,'FontSize',24);xlabel('niter');ylabel('\epsilon');
     title('Convergence de la m�thode explicite','FontSize',24)
