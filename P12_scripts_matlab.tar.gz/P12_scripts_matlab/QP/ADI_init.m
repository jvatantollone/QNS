%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Introduction au calcul scientifique par la pratique %%%%%%%
%%%%%%%    I. Danaila, P. Joly, S. M. Kaber et M. Postel    %%%%%%%
%%%%%%%                 Dunod, 2005                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                %
%     R�solution du syst�me                                      %
% ami(i)*X(j,i-1)+aci(i)*X(j,i)+api(i)*X(j,i+1)=fi(j,i),         %
%               i=1:n                                            %
%  pour chaque  j=1:m                                            %
%  la p�riodicit� est donn�e par X(j,1)=X(j,n)                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  PHASE D'INITIALISATION                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
       function [ami,api,alph,xs2]=ADI_init(ami,aci,api)

       n=length(ami);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                %
% Modification de la matrice du syst�me (1er et dernier �l diag) %
%         aci(1)=aci(1)-ami(1)                                   %
%         aci(n)=aci(n)-api(n)                                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
         aci(1)=aci(1)-ami(1);
         aci(n)=aci(n)-api(n);
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initialisation du second membre pour X2                        %
%         xs2(1)=ami(1)                                          %
%         xs2(i) =0                                              %
%         xs2(n)=api(n)                                          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
	       xs2=zeros(1,n);
         xs2(1)=ami(1);    
         xs2(n)=api(n);    

%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                  %
% R�solution du systeme tridiagonal                                %
% ami(i)*X(i-1)+aci(i)*X(i)+api(i)*X(i+1)=xs2(i),                  %
%      i=1,n                                                       %
%   (solution r�elle)-> stockage dans xs2                          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%
%--> algorithme de Thomas 
%-->                alph(i)=1/beta(i)
%                     ami(i)=ami(i)/beta(i-1)
%                     api(i)=api(i)/beta(i)
          alph=zeros(1,n);
          alph(1)=1.d0/aci(1);
        for i=2:n
          alph(i)=1.d0/(aci(i)-ami(i)*api(i-1)*alph(i-1));
          ami(i)=ami(i)*alph(i-1);
          api(i-1)=api(i-1)*alph(i-1);
	end

%
%-->r�solution du syst�me [M*] X2 = v1_x
%                       aci(i)=beta(i)*gamma(i)

          aci(1)=xs2(1);
        for i=2:n
	  aci(i)=xs2(i)-ami(i)*aci(i-1);
        end

%                       xs2(i) = X2(i) 
	xs2(n)=aci(n)*alph(n);
      for i=n-1:-1:1
        xs2(i)=aci(i)*alph(i)-api(i)*xs2(i+1);
      end
