%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Introduction au calcul scientifique par la pratique %%%%%%%
%%%%%%%    I. Danaila, P. Joly, S. M. Kaber et M. Postel    %%%%%%%
%%%%%%%                 Dunod, 2005                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%==============================================
% visualisation des iso-lignes pour deux champs
%==============================================

function visu_isos(xx,yy,u,fex,ncont)

     umax=max(max(u));umin=min(min(u));
     ucont=umin+[0:ncont-1]*(umax-umin)/(ncont-1);
     hold off
       cc=contour(xx,yy,u,ucont,'g');clabel(cc,'color','g');
     hold on;set(gca,'FontSize',24);xlabel('x');ylabel('y');
     set(findobj(gca,'Type','line','Color','g'),'LineWidth',2); 
       contour(xx,yy,fex,ucont,'r:');
     set(findobj(gca,'Type','line','Color','r'),'LineWidth',2); 
     title('Sol exacte en rouge / Sol num en vert','FontSize',24);
     drawnow;zoom on;