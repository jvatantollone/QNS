%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Introduction au calcul scientifique par la pratique %%%%%%%
%%%%%%%    I. Danaila, P. Joly, S. M. Kaber et M. Postel    %%%%%%%
%%%%%%%                 Dunod, 2005                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Test de la proc�dure de r�solution d'un         %
%   syst�me tridiagonal p�riodique (trid_per_c2D)  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;
format long e;

n=input('Dimension du systeme n='); 
m=input('Combien de systemes  m=');

% D�finition des vecteurs
for j=1:m
        % valeurs al�atoires
    v1=rand(1,n); 
    v3=rand(1,n);
    v2=-(v1+v3);
        % coeff de la matrice tridiagonale (vecteurs lignes)
    aa(j,:)=v1;
    ab(j,:)=v2;
    ac(j,:)=v3;
         % matrice du syst�me
    A=diag(v1(2:n),-1)+diag(v2,0)+diag(v3(1:n-1),1);
    A(1,n)=v1(1);
    A(n,1)=v3(n);
         % renforcement de la dominance diagonale
    ab(j,:)=ab(j,:)+norm(A,inf)*ones(1,n);
    A=A+diag(norm(A,inf)*ones(1,n));
          % solution impos�e (vecteurs colonnes)
    sol(:,j)=[j:j+n-1]';
          % membre de droite
    fi(:,j)=A*sol(:,j);
          % solution matlab
    solmat(:,j)=A\fi(:,j);
end

% solution avec trid_per_2
soltrid=trid_per_c2D(aa,ab,ac,fi');

% comparaison des solutions
for j=1:m
   fprintf('===== Systeme no= %i\n',j)
   fprintf('Sol trid // Sol matlab // Sol exacte\n')
    disp([soltrid(j,:)' solmat(:,j) sol(:,j)])
  pause
end
