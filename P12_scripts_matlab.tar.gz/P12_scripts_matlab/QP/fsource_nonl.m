%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Introduction au calcul scientifique par la pratique %%%%%%%
%%%%%%%    I. Danaila, P. Joly, S. M. Kaber et M. Postel    %%%%%%%
%%%%%%%                 Dunod, 2005                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Calcul du terme source (�quation non-lin�aire)%
%=================================================%
%f=[aa^2+bb^2-2 aa sin(aa*x)]*cos(aa*x)*sin(bb*y) %
%    aa=2*pi/L_x ; bb= 2*pi/L_y                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function fs=fsource_nonl(Lx,Ly,x,y)

aa=2*pi/Lx; bb=2*pi/Ly;
fs=(aa*aa+bb*bb-2*aa*sin(aa*x).*sin(bb*y)).*fexact(Lx,Ly,x,y);
