%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Introduction au calcul scientifique par la pratique %%%%%%%
%%%%%%%    I. Danaila, P. Joly, S. M. Kaber et M. Postel    %%%%%%%
%%%%%%%                 Dunod, 2005                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% rajoute une ligne au journal

function updatej(texto,ncarl)

global stj xyj txtH xyjmax xyjmin

ntot=length(texto);

for iligne=1:floor(ntot/ncarl)+1

sj=get(stj,'String');

xyj(2)=xyj(2)-txtH*1.5;
if xyj(2) <= xyjmin
   xyj(2)=xyjmin;
 %  xyj(4)=xyjmax;
   sjn=sj(2:size(sj,1),:);
else
	xyj(4)=min(xyj(4)+txtH*1.45,xyjmax);
	sjn=sj;
end

%disp(['xyj(2)=' num2str(xyj(2)) '  texto=' texto]);

ideb=1+ncarl*(iligne-1);
ifin=min(ncarl*iligne,ntot);

for k=ideb:ifin
   set(stj,'Position',xyj);
   set(stj,'String',char(sjn,texto(ideb:k)));pause(0.01);
end

end

