%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Introduction au calcul scientifique par la pratique %%%%%%%
%%%%%%%    I. Danaila, P. Joly, S. M. Kaber et M. Postel    %%%%%%%
%%%%%%%                 Dunod, 2005                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  resolution de l'equation                       %
%              -laplace(u)=f                      % 
%  domaine rectangulaire (Lx,Ly)                  % 
%  avec des conditions de periodicite en x et y   %
%==================================================
%  f=(aa*aa+bb*bb)*cos(aa*x)*sin(bb*y)            %
%    aa=2 pi/Lx ; bb= 2 pi/Ly                     %
%==================================================
%  fexact = cos(aa*x)*sin(bb*y)                   %
%=================================================%
%  u(i,j) calcule au point (xc(i),ym(j))          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Transformee de Fourier (FFT) en x             %
%     + resolution de systeme tridiag per en y    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

     close all; clear all;
     format long e;

%===============================%
%  Variables globales           %
%===============================%
     global dx dy Lx Ly;
     global nxm nym ;
     global ip im jp jm ic jc;

%===============================%
%  Donnees du programme         %
%===============================%
      Lx=1; Ly=2;
      nx=65;ny=129;
%===============================%
%  Maillage                     %
%===============================%
      nxm=nx-1  ;           nym=ny-1;
      dx=Lx/nxm ;           dy=Ly/nym;

      ic=1:nxm;             jc=1:nym; 

      xc=(ic-1)*dx ;        yc=(jc-1)*dy ;
      xm=(ic-0.5)*dx;       ym=(jc-0.5)*dy;

      ip=ic+1; ip(nxm)=1;   jp=jc+1; jp(nym)=1;
      im=ic-1; im(1)=nxm;   jm=jc-1; jm(1)=nym;

                        % points de calcul (maillage 2D)
      [xx,yy]=meshgrid(xc,ym);
       xx=xx';yy=yy';

%===============================%
%  Initialisation               %
%===============================%

      u   =zeros(nxm,nym);
      du  =zeros(nxm,nym);
      hc  =zeros(nxm,nym);
      rhs =zeros(nxm,nym);

%===============================%
%   Pas de temps                %
%===============================%

      dt=0.5/(1/(dx*dx)+1/(dy*dy))*100;
      bx=0.5*dt/(dx*dx);
      by=0.5*dt/(dy*dy);

%===============================%
%  Nombre d'onde + FFT          %
%===============================%
tcpu=cputime;

      kl=(cos(2*pi/nxm*(ic-1))-1)*2/(dx*dx);
     
      rhs=-fsource(Lx,Ly,xx,yy);

      uf=fft(rhs); % FFT de chaque colonne

%===============================%
%  Resolution du syst en y      %
%===============================%


      am=ones(nxm,nym)/(dy*dy);
      ac=(-2/(dy*dy)+kl)'*ones(1,nym);
      ap=ones(nxm,nym)/(dy*dy);

          % nombre d'onde = 0
      uf(1,1)=0;
      am(1,1)=0;
      ac(1,1)=1;
      ap(1,1)=0;
     
% avec optimisation
[am,ap,ac,xs2]=Phi_init(am,ac,ap);
               uff=Phi_step(am,ap,ac,xs2,uf);

%sans optimisation
%       uff=trid_per_c2D(am,ac,ap,uf);


%===============================%
%  FFT inverse                  %
%===============================%

       u=ifft(uff);u=real(u);

%===============================%
%   Solution exacte             %
%===============================%

         fex=fexact(Lx,Ly,xx,yy);   

%===============================%
%   Constante pour la sol num   %
%===============================%

      c0=fex(1,1)-u(1,1);
      u=u+c0;

%===============================%
%   Comparaison solutions       %
%===============================%

fprintf('\n=====Fin calcul ======= temps cpu =%d\n',cputime-tcpu)
     fprintf('Norme ||Uex-Unum|| =%d \n',norme_L2(fex-u));

%===============================%
%   Representation graphique    %
%===============================%

     ncont=11;
     umax=max(max(u));umin=min(min(u));
     ucont=umin+[0:ncont-1]*(umax-umin)/(ncont-1);

     figure(1);
     cc=contour(xx,yy,u,ucont,'g');clabel(cc,'color','g');
        hold on;
        contour(xx,yy,fex,ucont,'r');
     title('Sol exacte en rouge / Sol num en vert')
