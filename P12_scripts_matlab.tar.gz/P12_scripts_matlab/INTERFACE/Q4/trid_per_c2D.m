%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Introduction au calcul scientifique par la pratique %%%%%%%
%%%%%%%    I. Danaila, P. Joly, S. M. Kaber et M. Postel    %%%%%%%
%%%%%%%                 Dunod, 2005                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                %
%     Resolution du systeme (coeff 2D)                           %
% ami(j,i)*X(j,i-1)+aci(j,i)*X(j,i)+api(j,i)*X(j,i+1)=fi(j,i),   %
%               i=1:n                                            %
%  pour chaque  j=1:m                                            %
%  la periodicite est donnee par X(j,1)=X(j,n)                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  methode 2 (voir annexe B)                                     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
       function fi=trid_per(ami,aci,api,fi)

       [m,n]=size(ami);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                %
% Modification de la matrice du systeme (1er et dernier el diag) %
%         aci(j,1)=aci(j,1)-ami(j,1)                             %
%         aci(j,n)=aci(j,n)-api(j,n)                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
         aci(:,1)=aci(:,1)-ami(:,1);
         aci(:,n)=aci(:,n)-api(:,n);
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initialisation du second membre pour X2                        %
%         xs2(j,1)=ami(j,1)                                      %
%         xs2(j,i) =0                                            %
%         xs2(j,n)=api(j,n)                                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
	 xs2=zeros(m,n);
         xs2(:,1)=ami(:,1);    
         xs2(:,n)=api(:,n);    

%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                  %
% Resolution du systeme tridiagonal                                %
% ami(j,i)*X(j,i-1)+aci(j,i)*X(j,i)+api(j,i)*X(j,i+1)=xs2(j,i),    %
%      i=1,n                                                       %
%   (solution reelle)-> stockage dans xs2                          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%
%--> algo de thomas 
%-->                alph(i)=1/beta(i)
%                     ami(i)=ami(i)/beta(i-1)
%                     api(i)=api(i)/beta(i)
          alph=zeros(m,n);
          alph(:,1)=1.d0./aci(:,1);
        for i=2:n
          alph(:,i)=1.d0./(aci(:,i)-ami(:,i).*api(:,i-1).*alph(:,i-1));
          ami(:,i)=ami(:,i).*alph(:,i-1);
          api(:,i-1)=api(:,i-1).*alph(:,i-1);
	end

%
%-->resolution du systeme [M*] X2 = v1_x
%                       aci(i)=beta(i)*gamma(i)

          aci(:,1)=xs2(:,1);
        for i=2:n
	  aci(:,i)=xs2(:,i)-ami(:,i).*aci(:,i-1);
        end

%                       xs2(i) = X2(i) 
	xs2(:,n)=aci(:,n).*alph(:,n);
      for i=n-1:-1:1
        xs2(:,i)=aci(:,i).*alph(:,i)-api(:,i).*xs2(:,i+1);
      end
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                  %
% Resolution du systeme tridiagonal                                %
% ami(j,i)*X(j,i-1)+aci(j,i)*X(j,i)+api(j,i)*X(i+1)=fi(j,i), i=1,n %
%   (solution complexe)-> stockage dans fi                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%***------------------------------------------------------------
%***   Subs directe
%***------------------------------------------------------------

      for i=2:n
	fi(:,i)= fi(:,i)-ami(:,i).*fi(:,i-1);
      end


%***------------------------------------------------------------
%***  Subs inverse -->	dudx1(i)=X1(i)
%                            =gamma(n), i=n
%                            =gamma(i)-[c(i)/beta(i)]*X1(i+1)
%***------------------------------------------------------------

        fi(:,n)=fi(:,n).*alph(:,n);
%

        for i=n-1:-1:1
            fi(:,i)=fi(:,i).*alph(:,i)-api(:,i).*fi(:,i+1);
        end
%***------------------------------------------------------------
%***   Solution finale   	-->  v2_x = X*
%                              dudx1 = X = [X1] - [X*] [X2]
%***------------------------------------------------------------
	  xs1=zeros(m,1);
          xs1=(fi(:,1)+fi(:,n))./(1.d0+xs2(:,1)+xs2(:,n));

%
        for  i=1:n
          fi(:,i)=fi(:,i)-xs1.*xs2(:,i);
        end

%
