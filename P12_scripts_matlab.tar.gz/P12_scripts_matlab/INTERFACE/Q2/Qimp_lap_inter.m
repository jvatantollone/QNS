%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Introduction au calcul scientifique par la pratique %%%%%%%
%%%%%%%    I. Danaila, P. Joly, S. M. Kaber et M. Postel    %%%%%%%
%%%%%%%                 Dunod, 2005                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  resolution de l'equation                       %
%              du/dt -laplace(u)=f                % 
%  domaine rectangulaire (Lx,Ly)                  % 
%  avec des conditions de periodicite en x et y   %
%==================================================
%  f=(aa*aa+bb*bb)*cos(aa*x)*sin(bb*y)            %
%    aa=2 pi/Lx ; bb= 2 pi/Ly                     %
%==================================================
%  fexact = cos(aa*x)*sin(bb*y)                   %
%=================================================%
%  u(i,j) calcule au point (xc(i),ym(j))          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Schema d'Adams-Basfort + Crank-Nicholson      %
%     (u^(n+1)-u^n)/dt=(3/2)f^n -(1/2)*f^(n-1)    %
%                     + (1/2)laplace(u^n+u^(n+1)  %
%   inconditionnellement stable dans ce cas       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%================Optimisation resolution  syst periodiques==============
%                     (tcpu=6.54 resolution 81*201)

%     close all; clear all;
%     format long e;
     rmpath('../Q3');rmpath('../Q1');rmpath('../Q4');rmpath('../QNS');

%===============================%
%  Variables globales           %
%===============================%
     global dx dy Lx Ly;
     global nxm nym ;
     global ip im jp jm ic jc;

%===============================%
%  Donnees du programme         %
%===============================%
      Lx=1; Ly=2;
      nx=21;ny=51;
%===============================%
%  Maillage                     %
%===============================%
      nxm=nx-1  ;           nym=ny-1;
      dx=Lx/nxm ;           dy=Ly/nym;

      ic=1:nxm;             jc=1:nym; 

      xc=(ic-1)*dx ;        yc=(jc-1)*dy ;
      xm=(ic-0.5)*dx;       ym=(jc-0.5)*dy;

      ip=ic+1; ip(nxm)=1;   jp=jc+1; jp(nym)=1;
      im=ic-1; im(1)=nxm;   jm=jc-1; jm(1)=nym;

                        % points de calcul (maillage 2D)
      [xx,yy]=meshgrid(xc,ym);
       xx=xx';yy=yy';

%===============================%
%  Initialisation               %
%===============================%

      u   =zeros(nxm,nym);
      du  =zeros(nxm,nym);
      hc  =zeros(nxm,nym);
      rhs =zeros(nxm,nym);

%===============================%
%   Pas de temps                %
%===============================%

      dt=0.5/(1/(dx*dx)+1/(dy*dy))*100;
      bx=0.5*dt/(dx*dx);
      by=0.5*dt/(dy*dy);

%===============================%
%   Solution exacte             %
%===============================%

         fex=fexact(Lx,Ly,xx,yy);   

%===============================%
%   Optimisation syst per       %
%===============================%

[amix,apix,alphx,xs2x]=ADI_init(-bx*ones(1,nxm),(1+2*bx)*ones(1,nxm),-bx*ones(1,nxm));
[amiy,apiy,alphy,xs2y]=ADI_init(-by*ones(1,nym),(1+2*by)*ones(1,nym),-by*ones(1,nym));




%===============================%
%   Avancement en temps         %
%===============================%

       eps=1; nitermax=10000;
       niter=0;temps=0;

tcpu=cputime;updatej('**** debut calcul',ncarl);
   while((eps > 1e-6)&(niter <= nitermax))

         niter=niter+1;temps=temps+dt;

				     % membre de droite
	 rhs=-0.5*dt*hc;
	  hc=fsource(Lx,Ly,xx,yy);
	 rhs=rhs+1.5*dt*hc+dt*calc_lap(u);

                                     % premier pas ADI
	  du1=ADI_step(amix,apix,alphx,xs2x,rhs');
                                     % deuxieme pas ADI
	  du= ADI_step(amiy,apiy,alphy,xs2y,du1');

                            % critere d'arret
         eps=norme_L2(du);
                            % u^(n+1)
          u=u+du;

if(mod(niter,2) == 0); 
  updatej(['It=' num2str(niter) '  t=' num2str(temps) ' ||u^(n+1)-u^n||=' num2str(eps)],ncarl); 
figure(fg2);visu_isos(xx,yy,u,fex,11);
end;


    end;



%===============================%
%   Comparaison solutions       %
%===============================%

updatej(['*** Fin calcul : temps cpu=' num2str(cputime-tcpu)],ncarl);
updatej(['nx=' num2str(nx)  '  ny=' num2str(ny)],ncarl);
updatej(['It=' num2str(niter) '  t=' num2str(temps) ' ||u^(n+1)-u^n||=' num2str(eps)],ncarl); 
updatej(['Norme ||Uex-Unum|| =' num2str(norme_L2(fex-u))],ncarl);


     figure(fg2);figure(fg2);visu_isos(xx,yy,u,fex,11);



     updatej('Conclusion -> temps CPU reduit de 10 fois ',ncarl);
     updatej('!! c''est le schema a utiliser !!',ncarl);

     clear dx dy Lx Ly;
     clear nxm nym ;
     clear ip im jp jm ic jc;
clear u du xx yy hc rhs;
clear fex dt eps nitermax
clear amix apix alphx xs2x;
clear amiy apiy alphy xs2y;

rmpath('../Q2');
