%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Introduction au calcul scientifique par la pratique %%%%%%%
%%%%%%%    I. Danaila, P. Joly, S. M. Kaber et M. Postel    %%%%%%%
%%%%%%%                 Dunod, 2005                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Resolution des equations de Navier-Stokes 2D   %
%  domaine rectangulaire (Lx,Ly)                  % 
%  avec des conditions de periodicite en x et y   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

     close all; clear all;
     format long e;

%===============================%
%  Variables globales           %
%===============================%
     global dx dy Lx Ly;
     global nxm nym ;
     global ip im jp jm ic jc;

%===============================%
%  Donnees du programme         %
%===============================%
      Lx=2; Ly=0.5;
      nx=65;ny=65;
      rey=1000;
%===============================%
%  Maillage                     %
%===============================%
      nxm=nx-1  ;           nym=ny-1;
      dx=Lx/nxm ;           dy=Ly/nym;

      ic=1:nxm;             jc=1:nym; 

      xc=(ic-1)*dx ;        yc=(jc-1)*dy ;
      xm=(ic-0.5)*dx;       ym=(jc-0.5)*dy;

      ip=ic+1; ip(nxm)=1;   jp=jc+1; jp(nym)=1;
      im=ic-1; im(1)=nxm;   jm=jc-1; jm(1)=nym;

[xx,yy]=meshgrid(xm,ym);xx=xx';yy=yy';

%===============================%
%  Initialisation               %
%===============================%

      u   =zeros(nxm,nym);
      v   =zeros(nxm,nym);
      du  =zeros(nxm,nym);
      du1 =zeros(nxm,nym);

      gpu  =zeros(nxm,nym);
      gpv  =zeros(nxm,nym);
      hcu  =zeros(nxm,nym);
      hcv  =zeros(nxm,nym);

      pres =zeros(nxm,nym);
      sca  =zeros(nxm,nym);
     
      rhs =zeros(nxm,nym);
      phi =zeros(nxm,nym);

%===============================%
%  Condition initiale           %
%===============================%

      u=init_KH(Lx,Ly,xc,ym,1,0.1,20,0.5,0.5*Lx);

%[u,v]=init_dipole(Lx/2,Ly/2,min(Lx,Ly)/4,xc,yc);
%[rhs,phi]=init_vortex(Lx,Ly,xc,yc,Lx/4,Ly/2,0.,0);
%[u,v]=init_vortex(Lx,Ly,xc,yc,3*Lx/4,Ly/2,-0.5,0);

%u=u+rhs;
%v=v+phi;

sca=u;
figure(1);visu_vort(xc,yc,u,v,11);
%figure(2);visu_sca (xm,ym,sca,11);

%===============================%
%   Pas de temps                %
%===============================%

      dt=0.5/(1/(dx*dx)+1/(dy*dy))*10;

%===============================%
%   Optimisation ADI            %
%===============================%

      bx=0.5*dt/(dx*dx)/rey;
      by=0.5*dt/(dy*dy)/rey;

[amix,apix,alphx,xs2x]=ADI_init(-bx*ones(1,nxm),(1+2*bx)*ones(1,nxm),-bx*ones(1,nxm));
[amiy,apiy,alphy,xs2y]=ADI_init(-by*ones(1,nym),(1+2*by)*ones(1,nym),-by*ones(1,nym));


%===============================%
%   Optimisation eq pression    %
%===============================%

      kl=(cos(2*pi/nxm*(ic-1))-1)*2/(dx*dx);

      am=ones(nxm,nym)/(dy*dy);
      ac=(-2/(dy*dy)+kl)'*ones(1,nym);
      ap=ones(nxm,nym)/(dy*dy);

          % nombre d'onde = 0
      am(1,1)=0;
      ac(1,1)=1;
      ap(1,1)=0;
     
      [am,ap,ac,xs2]=Phi_init(am,ac,ap);


%===============================%
%   Avancement en temps         %
%===============================%

       nitermax=3;nprint=1;niso=10;
       niter=0; temps=0;
       affiche_div(u,v,niter,temps);

tc=cputime;
   while(niter <= nitermax)

         niter=niter+1;temps=temps+dt;

      % equation de qmvt pour u
      %===========================
                                     % membre de droite
	 rhs=-0.5*hcu;
	  hcu=calc_hcu(u,v);
	 rhs=dt*(rhs+1.5*hcu-gpu+calc_lap(u)/rey);
                                     % premier pas ADI
	  du1=ADI_step(amix,apix,alphx,xs2x,rhs');
                                     % deuxieme pas ADI
	  du= ADI_step(amiy,apiy,alphy,xs2y,du1');
                                     % u non-solenoidal
          u=u+du;

      % equation de qmvt pour v
      %===========================
                                     % membre de droite
	 rhs=-0.5*dt*hcv;
	  hcv=calc_hcv(u,v);
	 rhs=dt*(rhs+1.5*hcv-gpv+calc_lap(v)/rey);
                                     % premier pas ADI
	  du1=ADI_step(amix,apix,alphx,xs2x,rhs');
                                     % deuxieme pas ADI
	  du= ADI_step(amiy,apiy,alphy,xs2y,du1');
                                     % u non-solenoidal
          v=v+du;


      % calcul de la divergence du champ non-solenoidal
      %===========================
  
          rhs=((u(ip,jc)-u)/dx+ (v(ic,jp)-v)/dy)/dt;

      % resolution de l'equation de Poisson
      %===========================

          uf=fft(rhs); uf(1,1)=0;
          uff=Phi_step(am,ap,ac,xs2,uf);
          phi=real(ifft(uff));

      % correction du champ de vitesse     
      %===========================    

          u=u-dt*(phi-phi(im,jc))/dx;
          v=v-dt*(phi-phi(ic,jm))/dy;

      % calcul de la pression    
      %===========================    

          pres=pres+phi-dt/(2*rey)*calc_lap(phi);

      % nouveau gradient de pression    
      %===========================    

          gpu=(pres-pres(im,jc))/dx;
          gpv=(pres-pres(ic,jm))/dy;

         if(mod(niter,nprint) == 0); 
             affiche_div(u,v,niter,temps);
             visu_vort(xc,yc,u,v,niso);
         end;

    end;
fprintf('temps cpu =%d\n',cputime-tc);
