%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Introduction au calcul scientifique par la pratique %%%%%%%
%%%%%%%    I. Danaila, P. Joly, S. M. Kaber et M. Postel    %%%%%%%
%%%%%%%                 Dunod, 2005                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Resolution des equations de Navier-Stokes 2D   %
%  domaine rectangulaire (Lx,Ly)                  % 
%  avec des conditions de periodicite en x et y   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%     close all; clear all;
%     format long e;


%===============================%
%  Variables globales           %
%===============================%
     global dx dy Lx Ly;
     global nxm nym ;
     global ip im jp jm ic jc;

%     global movie_vor movie_sca;


%===============================%
%  Donnees du programme         %
%===============================%
      Lx=2; Ly=1;
      nx=65;ny=65;
      rey=1000;
      pec=1000;

      nitermax=300;
      nprint=10;niso=10;

%     movie_sca=moviein(floor(nitermax/nprint)+1);
%     movie_vor=moviein(floor(nitermax/nprint)+1);

updatej(['nx=' num2str(nx)  '  ny=' num2str(ny)],ncarl);
updatej(['Lx=' num2str(Lx)  '  Ly=' num2str(Ly)],ncarl);
updatej(['Re=' num2str(rey) '  Pe=' num2str(pec)],ncarl);
updatej('===',ncarl);

%===============================%
%  Maillage                     %
%===============================%
      nxm=nx-1  ;           nym=ny-1;
      dx=Lx/nxm ;           dy=Ly/nym;

      ic=1:nxm;             jc=1:nym; 

      xc=(ic-1)*dx ;        yc=(jc-1)*dy ;
      xm=(ic-0.5)*dx;       ym=(jc-0.5)*dy;

      ip=ic+1; ip(nxm)=1;   jp=jc+1; jp(nym)=1;
      im=ic-1; im(1)=nxm;   jm=jc-1; jm(1)=nym;

[xx,yy]=meshgrid(xm,ym);xx=xx';yy=yy';

%===============================%
%  Initialisation               %
%===============================%

      u   =zeros(nxm,nym);
      v   =zeros(nxm,nym);

      gpu  =zeros(nxm,nym);
      gpv  =zeros(nxm,nym);
      hcu  =zeros(nxm,nym);
      hcv  =zeros(nxm,nym);
      hcs  =zeros(nxm,nym);

      pres =zeros(nxm,nym);
      sca  =zeros(nxm,nym);
     
      rhs =zeros(nxm,nym);
      phi =zeros(nxm,nym);

%===============================%
%  Condition initiale           %
%===============================%

      u  =init_KH(Lx,Ly,xc,ym,1,Ly/4,20,0.25,0.5*Lx);
      sca=init_KH(Lx,Ly,xm,ym,1,Ly/4,20,0.00,0.5*Lx);


% visualisation de la condition initiale

ivisu=1;
figure(fg2);visu_vort(xc,yc,u,v,11,ivisu,0);
figure(fg3);visu_sca (xm,ym,sca,11,ivisu,0);



%===============================%
%   Pas de temps                %
%===============================%

      dt=0.5/(1/(dx*dx)+1/(dy*dy))*50;

%===============================%
%   Optimisation ADI            %
%===============================%

      bx=0.5*dt/(dx*dx)/rey;
      by=0.5*dt/(dy*dy)/rey;

[amix,apix,alphx,xs2x]=ADI_init(-bx*ones(1,nxm),(1+2*bx)*ones(1,nxm),-bx*ones(1,nxm));
[amiy,apiy,alphy,xs2y]=ADI_init(-by*ones(1,nym),(1+2*by)*ones(1,nym),-by*ones(1,nym));


%===============================%
%   Optimisation eq pression    %
%===============================%

      kl=(cos(2*pi/nxm*(ic-1))-1)*2/(dx*dx);

      am=ones(nxm,nym)/(dy*dy);
      ac=(-2/(dy*dy)+kl)'*ones(1,nym);
      ap=ones(nxm,nym)/(dy*dy);

          % nombre d'onde = 0
      am(1,1)=0;
      ac(1,1)=1;
      ap(1,1)=0;
     
      [am,ap,ac,xs2]=Phi_init(am,ac,ap);


updatej(['=== nitermax =' num2str(nitermax) ],ncarl);

calc_en_temps;

updatej(['nx=' num2str(nx)  '  ny=' num2str(ny)],ncarl);
updatej(['Lx=' num2str(Lx)  '  Ly=' num2str(Ly)],ncarl);
updatej(['Re=' num2str(rey) '  Pe=' num2str(pec)],ncarl);
updatej('===',ncarl);
updatej('On observe les tourbillons de K-H (cat-eyes)',ncarl);
updatej('===== Nice, isn''t it ? ====',ncarl);

     clear dx dy Lx Ly;
     clear nxm nym ;
     clear ip im jp jm ic jc;

clear u v gpu gpv hcu hcv hcs pres sca rhs phi
clear du du1 xx yy 
clear  dt nitermax
clear amix apix alphx xs2x;
clear amiy apiy alphy xs2y;
clear kl uf uff   am ac ap

rmpath('../QNS');

