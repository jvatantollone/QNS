%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Introduction au calcul scientifique par la pratique %%%%%%%
%%%%%%%    I. Danaila, P. Joly, S. M. Kaber et M. Postel    %%%%%%%
%%%%%%%                 Dunod, 2005                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Calcul des termes explicites pour u           %
%     Hc_u=-(du^2/dx + d(uv)/dy)                  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


       function hcu=calc_hcu(u,v)

global dx dy
global im ip jp jm ic jc


hcu = -0.25/dx*((u(ip,jc)+u).*(u(ip,jc)+u) - (u(im,jc)+u).*(u(im,jc)+u))...
      -0.25/dy*((u(ic,jp)+u).*(v(ic,jp)+v(im,jp))-(u(ic,jm)+u).*(v(im,jc)+v));
 
