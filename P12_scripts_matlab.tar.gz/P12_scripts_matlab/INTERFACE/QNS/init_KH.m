%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Introduction au calcul scientifique par la pratique %%%%%%%
%%%%%%%    I. Danaila, P. Joly, S. M. Kaber et M. Postel    %%%%%%%
%%%%%%%                 Dunod, 2005                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Condition initiale -> jet 2D                  %
%     pour l'insatbilite de Kelvin-helmholtz      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


       function u=init_KH(Lx,Ly,x,y,U0,Rj,Pj,Ax,lamx)

global dx dy
global im ip jp jm ic jc

[xx,yy]=meshgrid(x,y);xx=xx';yy=yy';

rr=yy-Ly/2;

u=U0*0.5d0*(1.d0+tanh(0.5*Pj*(1-abs(rr)/Rj)));

difu=(u(ic,jp)-u)/dy;difu=abs(difu);
difu=difu/max(max(difu));

%       u=u+U0*Ax*sin(2*pi/lamx*xx);

        u=u+Ax*u.*sin(2*pi/lamx*xx);
