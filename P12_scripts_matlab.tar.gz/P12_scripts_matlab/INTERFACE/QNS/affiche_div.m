%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Introduction au calcul scientifique par la pratique %%%%%%%
%%%%%%%    I. Danaila, P. Joly, S. M. Kaber et M. Postel    %%%%%%%
%%%%%%%                 Dunod, 2005                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Calcul de la divergence -> affichage          %
%     =du/dx+dv/dy                                %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


       function affiche_div(u,v,niter,temps)

global dx dy
global im ip jp jm ic jc
global ncarl ;

      divns = (u(ip,jc)-u)/dx+ (v(ic,jp)-v)/dy;

divmax=max(max(abs(divns)));
divtot=sqrt(sum(sum(divns.*divns))*dx*dy);

%     fprintf('It=%d   temps=%d  divmax=%d divtot=%d \n',niter,temps,divmax,divtot);

 updatej(['It=' num2str(niter) '  t=' num2str(temps) ' divmax=' num2str(divmax)],ncarl); 
