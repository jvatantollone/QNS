%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Introduction au calcul scientifique par la pratique %%%%%%%
%%%%%%%    I. Danaila, P. Joly, S. M. Kaber et M. Postel    %%%%%%%
%%%%%%%                 Dunod, 2005                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Visualisation des contours du scalaire pas.   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


       function visu_sca(x,y,sca,ncont,ivisu,temps)

global dx dy
global im ip jp jm ic jc
%global movie_sca


[xx,yy]=meshgrid(x,y);xx=xx';yy=yy';

%     umax=max(max(sca));umin=min(min(sca));
%     ucont=umin+[0:ncont-1]*(umax-umin)/(ncont-1);

%cc=contourf(xx,yy,sca,ucont);drawnow

pcolor(xx,yy,sca);axis equal;shading('interp');drawnow;

title(['Scalaire   t=' num2str(temps)]);

%movie_sca(:,ivisu)=getframe;
