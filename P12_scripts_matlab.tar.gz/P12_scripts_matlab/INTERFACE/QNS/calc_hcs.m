%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Introduction au calcul scientifique par la pratique %%%%%%%
%%%%%%%    I. Danaila, P. Joly, S. M. Kaber et M. Postel    %%%%%%%
%%%%%%%                 Dunod, 2005                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Calcul des termes explicites pour le scalaire %
%     Hc_s=-(d(u*sca)/dx + d(v*sca)/dy)           %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


       function hcs=calc_hcs(u,v,sca)

global dx dy
global im ip jp jm ic jc


hcs = -0.5/dx*(u(ip,jc).*(sca(ip,jc)+sca) - u.*(sca(im,jc)+sca))...
      -0.5/dy*(v(ic,jp).*(sca(ic,jp)+sca) - v.*(sca(ic,jm)+sca));
 
