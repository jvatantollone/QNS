%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Introduction au calcul scientifique par la pratique %%%%%%%
%%%%%%%    I. Danaila, P. Joly, S. M. Kaber et M. Postel    %%%%%%%
%%%%%%%                 Dunod, 2005                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Condition initiale -> vortex 2D               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


       function [u,v]=init_vortex(Lx,Ly,x,y,xv,yv,uin,vin,pm)

global nxm nym dx dy
global im ip jp jm ic jc


%xv=Lx/2.d0;
%yv=Ly/2.d0;

lv=min([xv,Lx-xv,yv,Ly-yv])*0.400*sqrt(2.);


psi0=0.1;


for jy=1:nym
for jx=1:nxm
uloc=(x(jx)-xv)^2+(y(jy)-yv)^2;
uloc=pm*psi0*exp(-uloc/lv^2);
u(jx,jy)=uin-2.d0*(y(jy)-yv)*uloc/lv^2;
v(jx,jy)=vin+2.d0*(x(jx)-xv)*uloc/lv^2;
end
end
