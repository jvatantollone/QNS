%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Introduction au calcul scientifique par la pratique %%%%%%%
%%%%%%%    I. Danaila, P. Joly, S. M. Kaber et M. Postel    %%%%%%%
%%%%%%%                 Dunod, 2005                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%===============================%
%   Avancement en temps         %
%===============================%


       niter=0; temps=0;
       affiche_div(u,v,niter,temps);

tc=cputime;
   while(niter <= nitermax)

         niter=niter+1;temps=temps+dt;

      % equation de qmvt pour u
      %===========================
                                     % membre de droite
	 rhs=-0.5*hcu;
	  hcu=calc_hcu(u,v);
	 rhs=dt*(rhs+1.5*hcu-gpu+calc_lap(u)/rey);
                                     % premier pas ADI
	  du1=ADI_step(amix,apix,alphx,xs2x,rhs');
                                     % deuxieme pas ADI
	  du= ADI_step(amiy,apiy,alphy,xs2y,du1');
                                     % u non-solenoidal
          u=u+du;

      % equation de qmvt pour v
      %===========================
                                     % membre de droite
	 rhs=-0.5*dt*hcv;
	  hcv=calc_hcv(u,v);
	 rhs=dt*(rhs+1.5*hcv-gpv+calc_lap(v)/rey);
                                     % premier pas ADI
	  du1=ADI_step(amix,apix,alphx,xs2x,rhs');
                                     % deuxieme pas ADI
	  du= ADI_step(amiy,apiy,alphy,xs2y,du1');
                                     % u non-solenoidal
          v=v+du;


      % calcul de la divergence du champ non-solenoidal
      %===========================
  
          rhs=((u(ip,jc)-u)/dx+ (v(ic,jp)-v)/dy)/dt;

      % resolution de l'equation de Poisson
      %===========================

          uf=fft(rhs); uf(1,1)=0;
          uff=Phi_step(am,ap,ac,xs2,uf);
          phi=real(ifft(uff));

      % correction du champ de vitesse     
      %===========================    

          u=u-dt*(phi-phi(im,jc))/dx;
          v=v-dt*(phi-phi(ic,jm))/dy;

      % calcul de la pression    
      %===========================    

          pres=pres+phi-dt/(2*rey)*calc_lap(phi);

      % nouveau gradient de pression    
      %===========================    

          gpu=(pres-pres(im,jc))/dx;
          gpv=(pres-pres(ic,jm))/dy;

      % equation pour le scalaire passif
      %===========================
                                     % membre de droite
	 rhs=-0.5*hcs;
	  hcs=calc_hcs(u,v,sca);
	 rhs=dt*(rhs+1.5*hcs+calc_lap(sca)/pec);
                                     % premier pas ADI
	  du1=ADI_step(amix,apix,alphx,xs2x,rhs');
                                     % deuxieme pas ADI
	  du= ADI_step(amiy,apiy,alphy,xs2y,du1');
                                     % u non-solenoidal
          sca=sca+du;

         if(mod(niter,nprint) == 0); 
             affiche_div(u,v,niter,temps);ivisu=ivisu+1;
             figure(fg2);visu_vort(xc,yc,u,v,niso,ivisu,temps);
             figure(fg3);visu_sca (xm,ym,sca,niso,ivisu,temps);
          end;

    end;
updatej(['*******temps CPU =' num2str(cputime-tc)], ncarl);
