%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Introduction au calcul scientifique par la pratique %%%%%%%
%%%%%%%    I. Danaila, P. Joly, S. M. Kaber et M. Postel    %%%%%%%
%%%%%%%                 Dunod, 2005                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Condition initiale -> jet 2D                  %
%     pour l'insatbilite de Kelvin-helmholtz      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


       function [u,v]=init_dipole(xv,yv,lv,x,y)

global nxm nym dx dy
global im ip jp jm ic jc


%---------------coordinates of the center of the dipole
%       xv=0.d0
%       yv=0.d0
%
%----------dipole radius: a -------
%       lv=1.d0
%
%       psi0=0.0065d0;
       psi0=0.5d0;
%----------- k=3.83/a --------------
       uu0=3.83d0/lv;
%----------  U=-k*psi0/2*J0(3.83)--
       u0=0.5d0*uu0*psi0*0.402758809533;
%----------
       for j=1:nym
        for i=1:nxm
          uloc=(x(i)-xv)*(x(i)-xv)+(y(j)-yv)*(y(j)-yv);
          uloc=sqrt(uloc);
          if(uloc ~= 0)
           cth=(x(i)-xv)/uloc;
           sth=(y(j)-yv)/uloc;
          else
           cth=0.d0;
           sth=0.d0;
          end
%
%             cth=(-cth-sth)/dsqrt(2.d0)
%
          if(uloc < lv) 
             rho(i,j)=psi0*sth*besselj(1,uu0*uloc);
          else
%             rho(i,j)=-u0*sth*(uloc-lv*lv/uloc);
             rho(i,j)=0.d0;
          end
        end
       end


%-----vitesses---------

      u=(rho(ic,jp)-rho(ic,jc))/dy;
      v=-(rho(ip,jc)-rho(ic,jc))/dx;


