%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Introduction au calcul scientifique par la pratique %%%%%%%
%%%%%%%    I. Danaila, P. Joly, S. M. Kaber et M. Postel    %%%%%%%
%%%%%%%                 Dunod, 2005                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  resolution de l'equation                       %
%              du/dt -laplace(u)=f                % 
%  domaine rectangulaire (Lx,Ly)                  % 
%  avec des conditions de periodicite en x et y   %
%==================================================
%  f=(aa*aa+bb*bb)*cos(aa*x)*sin(bb*y)            %
%    aa=2 pi/Lx ; bb= 2 pi/Ly                     %
%==================================================
%  fexact = cos(aa*x)*sin(bb*y)                   %
%=================================================%
%  u(i,j) calcule au point (xc(i),ym(j))          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Schema explicite                              %
%     u^(n+1)=u^n + dt*(f^n + laplace(u^n))       %
%   condition de stabilite                        %
%     dt < 0.5 /(1/dx^2+1/dy^2)                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%     close all; clear all;
%     format long e;

%===============================%
%  Variables globales           %
%===============================%
     global dx dy Lx Ly;
     global nxm nym ;
     global ip im jp jm ic jc;

%===============================%
%  Donnees du programme         %
%===============================%
      Lx=1; Ly=2;
      nx=21;ny=51;
%===============================%
%  Maillage                     %
%===============================%
      nxm=nx-1  ;           nym=ny-1;
      dx=Lx/nxm ;           dy=Ly/nym;

      ic=1:nxm;             jc=1:nym; 

      xc=(ic-1)*dx ;        yc=(jc-1)*dy ;
      xm=(ic-0.5)*dx;       ym=(jc-0.5)*dy;

      ip=ic+1; ip(nxm)=1;   jp=jc+1; jp(nym)=1;
      im=ic-1; im(1)=nxm;   jm=jc-1; jm(1)=nym;

                        % points de calcul (maillage 2D)
      [xx,yy]=meshgrid(xc,ym);
       xx=xx';yy=yy';

%===============================%
%  Initialisation               %
%===============================%

      u   =zeros(nxm,nym);
     du   =zeros(nxm,nym);

%===============================%
%   Pas de temps                %
%===============================%

      dt=0.5/(1/(dx*dx)+1/(dy*dy));

%===============================%
%   Avancement en temps         %
%===============================%

       eps=1; nitermax=10000;
       niter=0;temps=0;

tcpu=cputime;updatej('**** debut calcul',ncarl);
   while((eps > 1e-6)&(niter <= nitermax))

         niter=niter+1;temps=temps+dt;

                            % u^(n+1)-u^n

         du=dt*(fsource(Lx,Ly,xx,yy)+calc_lap(u));

                            % critere d'arret
         eps=norme_L2(du);
                            % u^(n+1)
         u=u+du;

         if(mod(niter,10) == 0); 
            fprintf('It=%d   temps=%d ||u-uold||=%d \n',niter,temps,eps);

        end;
    end;

%===============================%
%   Solution exacte             %
%===============================%

         fex=fexact(Lx,Ly,xx,yy);   

%===============================%
%   Comparaison solutions       %
%===============================%

fprintf('\n=====Fin calcul ======= temps cpu =%d\n',cputime-tcpu)
     fprintf('It=%d   temps=%d ||u-uold||=%d \n',niter,temps,eps);
     fprintf('Norme ||Uex-Unum|| =%d \n',norme_L2(fex-u));


%===============================%
%   Representation graphique    %
%===============================%

     ncont=11;
     umax=max(max(u));umin=min(min(u));
     ucont=umin+[0:ncont-1]*(umax-umin)/(ncont-1);

     figure;
     cc=contour(xx,yy,u,ucont,'g');clabel(cc,'color','g');
        hold on;
        contour(xx,yy,fex,ucont,'r');
     title('Sol exacte en rouge / Sol num en vert')
