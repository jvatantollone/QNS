%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Introduction au calcul scientifique par la pratique %%%%%%%
%%%%%%%    I. Danaila, P. Joly, S. M. Kaber et M. Postel    %%%%%%%
%%%%%%%                 Dunod, 2005                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function visu_isos(xx,yy,u,fex,ncont)

     umax=max(max(u));umin=min(min(u));
     ucont=umin+[0:ncont-1]*(umax-umin)/(ncont-1);
        hold off
     cc=contour(xx,yy,u,ucont,'g');clabel(cc,'color','g');
        hold on;
contour(xx,yy,fex,ucont,'r');
title('Sol exacte en rouge / Sol num en vert');drawnow;zoom on;
