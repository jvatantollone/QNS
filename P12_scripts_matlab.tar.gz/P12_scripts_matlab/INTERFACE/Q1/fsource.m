%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Introduction au calcul scientifique par la pratique %%%%%%%
%%%%%%%    I. Danaila, P. Joly, S. M. Kaber et M. Postel    %%%%%%%
%%%%%%%                 Dunod, 2005                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Calcul du terme source f^n                    %
%=================================================%
%  f=(aa*aa+bb*bb)*cos(aa*x)*sin(bb*y)            %
%    aa=2 pi/Lx ; bb= 2 pi/Ly                     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function fs=source(Lx,Ly,x,y)

     aa=2*pi/Lx; bb=2*pi/Ly;

     fs=(aa*aa+bb*bb)*(cos(aa*x).*sin(bb*y));

