%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Introduction au calcul scientifique par la pratique %%%%%%%
%%%%%%%    I. Danaila, P. Joly, S. M. Kaber et M. Postel    %%%%%%%
%%%%%%%                 Dunod, 2005                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
updatej('---',ncarl)
updatej('  resolution de l''equation ',ncarl)
updatej('   d(u^2)/dx -laplace(u)=f ',ncarl)
updatej(' par une approche pseudo-instationnaire ',ncarl)
updatej('   du/dt + d(u^2)/dx -laplace(u)=f',ncarl) 
updatej(' domaine rectangulaire (Lx,Ly)',ncarl) 
updatej(' avec des conditions de periodicite en x et y',ncarl)
updatej('---',ncarl)
updatej(' f=(aa*aa+bb*bb)*cos(aa*x)*sin(bb*y) -aa*cos(aa*x)*sin(bb*y)*[sin(aa*x)*sin(bb*y)]',ncarl)
updatej('   aa=2 pi/Lx ; bb= 2 pi/Ly',ncarl)
updatej('l''avantage est de connaitre la sol exacte',ncarl)
updatej(' fexact = cos(aa*x)*sin(bb*y)',ncarl)
updatej('---',ncarl)
updatej(' u(i,j) calcule au point (xc(i),ym(j))',ncarl)
updatej('---',ncarl)

updatej('  Schema implicite  ',ncarl)
updatej('  Adams-Basfort + Crank-Nicholson  ',ncarl)
updatej('  (u^(n+1)-u^n)/dt=(3/2)H^n - (1/2)*H^(n-1) + (1/2)laplace(u^n+u^(n+1) ',ncarl)
updatej('  H^n = f^n - d(u^n*u^n)/dx  ',ncarl)
updatej('   il existe une condition de stabilite ',ncarl)
updatej('   !!! on va prendre dt=100*0.5/(1/(dx*dx)+1/(dy*dy)) !!!',ncarl)
updatej('---',ncarl) 

