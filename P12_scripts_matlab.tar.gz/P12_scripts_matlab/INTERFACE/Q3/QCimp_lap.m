%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Introduction au calcul scientifique par la pratique %%%%%%%
%%%%%%%    I. Danaila, P. Joly, S. M. Kaber et M. Postel    %%%%%%%
%%%%%%%                 Dunod, 2005                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  resolution de l'equation                       %
%      du/dt +d(u^2)/dx-laplace(u)=f              % 
%  domaine rectangulaire (Lx,Ly)                  % 
%  avec des conditions de periodicite en x et y   %
%==================================================
%  f=(aa*aa+bb*bb)*cos(aa*x)*sin(bb*y)            %
%   -aa*cos(aa*x)*sin(bb*y)*[sin(aa*x)*sin(bb*y)] %
%    aa=2 pi/Lx ; bb= 2 pi/Ly                     %
%==================================================
%  fexact = cos(aa*x)*sin(bb*y)                   %
%=================================================%
%  u(i,j) calcule au point (xc(i),ym(j))          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Schema d'Adams-Basfort + Crank-Nicholson      %
%     (u^(n+1)-u^n)/dt=(3/2)Hc^n -(1/2)*Hc^(n-1)  %
%                     + (1/2)laplace(u^n+u^(n+1)  %
%   condition de stabilite                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


     close all; clear all;
     format long e;

%===============================%
%  Variables globales           %
%===============================%
     global dx dy Lx Ly;
     global nxm nym ;
     global ip im jp jm ic jc;

%===============================%
%  Donnees du programme         %
%===============================%
      Lx=1; Ly=2;
      nx=21;ny=51;
%===============================%
%  Maillage                     %
%===============================%
      nxm=nx-1  ;           nym=ny-1;
      dx=Lx/nxm ;           dy=Ly/nym;

      ic=1:nxm;             jc=1:nym; 

      xc=(ic-1)*dx ;        yc=(jc-1)*dy ;
      xm=(ic-0.5)*dx;       ym=(jc-0.5)*dy;

      ip=ic+1; ip(nxm)=1;   jp=jc+1; jp(nym)=1;
      im=ic-1; im(1)=nxm;   jm=jc-1; jm(1)=nym;

                        % points de calcul (maillage 2D)
      [xx,yy]=meshgrid(xc,ym);
       xx=xx';yy=yy';

%===============================%
%  Initialisation               %
%===============================%

      u   =zeros(nxm,nym);
      du  =zeros(nxm,nym);
      hc  =zeros(nxm,nym);
      rhs =zeros(nxm,nym);

%===============================%
%   Pas de temps                %
%===============================%

      dt=0.5/(1/(dx*dx)+1/(dy*dy))*100;
      bx=0.5*dt/(dx*dx);
      by=0.5*dt/(dy*dy);

%===============================%
%   Optimisation syst per       %
%===============================%

[amix,apix,alphx,xs2x]=ADI_init(-bx*ones(1,nxm),(1+2*bx)*ones(1,nxm),-bx*ones(1,nxm));
[amiy,apiy,alphy,xs2y]=ADI_init(-by*ones(1,nym),(1+2*by)*ones(1,nym),-by*ones(1,nym));


%===============================%
%   Avancement en temps         %
%===============================%

       eps=1; nitermax=1000;
       niter=0;temps=0;

tcpu=cputime;
   while((eps > 1e-6)&(niter <= nitermax))

         niter=niter+1;temps=temps+dt;

				     % membre de droite
	 rhs=-0.5*dt*hc;
	  hc=calc_hc(Lx,Ly,xx,yy,u);
	 rhs=rhs+1.5*dt*hc+dt*calc_lap(u);

                                     % premier pas ADI
	  du1=ADI_step(amix,apix,alphx,xs2x,rhs');
                                     % deuxieme pas ADI
	  du= ADI_step(amiy,apiy,alphy,xs2y,du1');

                            % critere d'arret
         eps=norme_L2(du);
                            % u^(n+1)
          u=u+du;

         if(mod(niter,10) == 0); 
             fprintf('It=%d   temps=%d ||u-uold||=%d \n',niter,temps,eps);
         end;

    end;

%===============================%
%   Solution exacte             %
%===============================%

         fex=fexact(Lx,Ly,xx,yy);   

%===============================%
%   Comparaison solutions       %
%===============================%

fprintf('\n=====Fin calcul ======= temps cpu =%d\n',cputime-tcpu)
     fprintf('It=%d   temps=%d ||u-uold||=%d \n',niter,temps,eps);
     fprintf('Norme ||Uex-Unum|| =%d \n',norme_L2(fex-u));

%===============================%
%   Representation graphique    %
%===============================%

     ncont=11;
     umax=max(max(u));umin=min(min(u));
     ucont=umin+[0:ncont-1]*(umax-umin)/(ncont-1);

     figure(1);
     cc=contour(xx,yy,u,ucont,'g');clabel(cc,'color','g');
        hold on;
        contour(xx,yy,fex,ucont,'r');
     title('Sol exacte en rouge / Sol num en vert')
